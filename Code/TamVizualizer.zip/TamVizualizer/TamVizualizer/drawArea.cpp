#include <QtGui>
#include <qthread.h>
#include "qprinter.h"
#include "drawArea.h"
#include "qprintdialog.h"
#include <sstream>
#include <fstream>
#include <iostream>
#include <cstring>
#include <string>
#include <Windows.h>
#include <ctime>
#include <iomanip>

using namespace std;

/*Main constructor for the DrawArea object
Sets upt the windows touch event connection and 
the click event connections also initializes a list
of ten colors*/
DrawArea::DrawArea(QWidget *parent)
	: QWidget(parent)
{
	setAttribute(Qt::WA_AcceptTouchEvents);
	setAttribute(Qt::WA_StaticContents);

	//for (int i = 0; i < 10; i++) fingers[i] = -1;

	idColors
		<< QColor("red")
		<< QColor("yellow")
		<< QColor("blue")
		<< QColor("green")
		<< QColor("orange")
		<< QColor("brown")
		<< QColor("pink")
		<< QColor("cyan")
		<< QColor("purple")
		<< QColor("black");
}

/*Supplementary function to display th elist of touch points
into the debug monitor*/
void DrawArea::printthedata()
{
	foreach(touchData data, thePoints)
	{
		qDebug() << "POINT: \n";
		qDebug() << "X: " << data.x;
		qDebug() << "Y: " << data.y;
		qDebug() << "ID: " << data.id;
		qDebug() << "TIME (ms): " << data.time;
	}
}

/*Changes the global brushSize variable to the selected size i*/
void DrawArea::doResizeBrush(int i)
{
	brushSize = i;
	qDebug() << "BRUSH SIZE: " << i;
}

/*Changes the global map variable to the selected map fuunction*/
void DrawArea::doMap(int map)
{
	switch (map)
	{
	case 1:
		mapping = 1;
		qDebug() << "MAPPING FUNCTION SELECTED IS 1";
		break;
	case 2:
		mapping = 2;
		qDebug() << "MAPPING FUNCTION SELECTED IS 2";
		break;
	case 3:
		mapping = 0.5;
		qDebug() << "MAPPING FUNCTION SELECTED IS 1/2";
		break;
	default: 
		mapping = 1;
	}
}



/*Opens a file stream to save the touch points into
goes trough the list of touch points and writes them in order*/
bool DrawArea::doSaveGesture(QString fileName, QString fileType)
{
	/* EDIT: (05/26):
	Added choice of JSON file detection. Not fully implemented.
	*/
	
	qDebug() << "SAVING THE FILE TO " << fileName;

	if (fileType.toLower() == "json") {
		/* EDITS: Links below
		http://doc.qt.io/qt-5/json.html
		http://doc.qt.io/qt-5/qtcore-json-savegame-example.html 
		*/
		QFile saveFile(fileName);

		if (!saveFile.open(QIODevice::WriteOnly)) {
			qDebug() << "Couldn't open save file.";
			return false;
		}

		QJsonObject json;
		QJsonArray pointArray;
		foreach(touchData data, thePoints) {
			QJsonObject dataStruct;
			dataStruct["X"] = data.x;
			dataStruct["Y"] = data.y;
			dataStruct["ID"] = data.id;
			dataStruct["TM"] = data.time;
			pointArray.append(dataStruct);
		}
		json["POINTS"] = pointArray;

		QJsonDocument saveDoc(json);
		saveFile.write(saveDoc.toJson());
	} else if (fileType.toLower() == "csv") {
		ofstream file;
		file.open(fileName.toStdString());

		foreach(touchData data, thePoints) {
			file << data.x << "," << data.y << "," << data.id << "," << data.time << endl;
		}
	} else {
		qDebug() << "ERROR: File Type Invalid" << endl;
	}

	return true;
}

/*Opens a file stream to read the touchpoints, 
reads the data one line at a time and then
reads the four elements contained on the line
while adding this touch pounts objects into the touchpoint list*/
bool DrawArea::doOpenGesture(QString fileName, QString fileType)
{
	/* EDIT: (05/26):
	Added choice of JSON file detection. Not fully implemented.
	*/

	qDebug() << "OPENING A FILE";
	thePoints.clear();

	if (fileType.toLower() == "json") {
		QFile loadFile(fileName);

		if (!loadFile.open(QIODevice::ReadOnly)) {
			qWarning("Couldn't open save file.");
			return false;
		}

		QByteArray saveData = loadFile.readAll();

		QJsonDocument loadDoc(QJsonDocument::fromJson(saveData));

		QJsonObject json = loadDoc.object();

		thePoints.clear();
		QJsonArray pointsArray = json["POINTS"].toArray();
		for (int i = 0; i < pointsArray.size(); i++) {
			QJsonObject dataElem = pointsArray[i].toObject();
			touchData data;
			data.x = dataElem["X"].toInt();
			data.y = dataElem["Y"].toInt();
			data.id = dataElem["ID"].toInt();
			data.time = dataElem["TM"].toInt();

			thePoints.append(data);
		}
	} else if (fileType.toLower() == "csv") {
		ifstream file;
		file.open(fileName.toStdString());
		string line;

		while (getline(file, line))
		{
			touchData data;
			istringstream s(line);
			string field;
			getline(s, field, ',');
			data.x = stoi(field);
			getline(s, field, ',');
			data.y = stoi(field);
			getline(s, field, ',');
			data.id = stoi(field);
			getline(s, field, ',');
			data.time = stoi(field);
			thePoints.append(data);

		}
	}
	playback();
	return true;
}

/*Goes trough the touchPoint list and extracts the X and Y axis
and the id then draws a rectangle the size of the brush size
until the list is empty*/
void DrawArea::playback()
{
	qDebug() << "ON PLAYBACK";
	//clearScreen();

	int beginTime = clock();
	int time;
	int index = 0;
	foreach(touchData data, thePoints)
	{

		time = clock();
		qDebug() << "  SLEEP FOR " << (data.time - (time - beginTime)) << endl;
		if (data.time - (time - beginTime) > 0) {
			// Pause between touch data 
			QThread::yieldCurrentThread();
			qApp->processEvents();

			QThread::msleep(data.time - (time - beginTime));
		}

		// Update
		if (data.x < 0 || data.y < 0)	fingers.remove(data.id);
		else							fingers[data.id] = index;

		// Next Frame
		clearScreen();
		drawScreen();

		index++;
	}
	thePoints.clear();
}

void DrawArea::updateData(touchData data){
	if (data.x < 0 || data.y < 0) {
		qDebug() << "POINT: [RELEASE]";
		qDebug() << "ID: " << data.id;
		qDebug() << "TIME (ms): " << data.time;
		
		fingers.remove(data.id);
	} else {
		qDebug() << "POINT: \n";
		qDebug() << "X: " << data.x;
		qDebug() << "Y: " << data.y;
		qDebug() << "ID: " << data.id;
		qDebug() << "TIME (ms): " << data.time;

		fingers[data.id] = thePoints.size();
	}
	thePoints << data;
	/*int i = 0;
	for (; i < 10; i++) {
		if (fingers[i] == data.id || fingers[i] == -1){
			fingers[i] = thePoints.size();
			break;
		}
	}
	if (i == 10){
		qDebug() << "ERROR: Too many finger input" << endl;
	} else {
		thePoints << data;
	}*/
}

void DrawArea::drawScreen() {
	float avgX = 0, avgY = 0;
	int  count = 0;
	touchData data;
	touchData circle[3];
	foreach(int index, fingers){
		data = thePoints[index];
		drawFinger(data);

		avgX += data.x;
		avgY += data.y;

		if (count < 3) circle[count] = data;
		count++;
	}

	// Average of ALL points
	if (count > 1){
		avgX /= count;
		avgY /= count;
		QPainter painter(&image);
		QRectF testrect = QRectF(avgX - 2, avgY - 2, 4, 4);
		painter.setBrush(idColors.at(0));
		painter.drawEllipse(testrect);

		painter.end();
		
		// Update small portion of the screen
		bool b = this->updatesEnabled();
		int rad = 2;
		update(testrect.toRect().adjusted(-rad, -rad, +rad, +rad));
	}

	// Best Fit Circle for all points (work-in-progress)
	float centerX = 0, centerY = 0, radius = 5, avgR = 0;
	if (count >= 3){
		avgX = 0;
		avgY = 0;
		count = 0;
		foreach(int i, fingers){
			foreach(int j, fingers){
				if (i <= j) continue;
				foreach(int k, fingers){
					if (j <= k) continue;

					if (getCircle(thePoints[i], thePoints[j], thePoints[k], centerX, centerY, radius)) {
						avgX += centerX;
						avgY += centerY;
						avgR += radius;
						count++;
					}
				}
			}
		}
		avgX /= count;
		avgY /= count;
		avgR /= count;

		//&& getCircle(circle[0], circle[1], circle[2], centerX, centerY, radius)) {
		QPainter painter(&image);
		QRectF testrect = QRectF(avgX - 5, avgY - 5, 10, 10);
		QRectF testrect2 = QRectF(avgX - avgR, avgY - avgR, 2 * avgR, 2 * avgR);
		painter.setBrush(idColors.at(0));
		painter.drawEllipse(testrect);
		painter.drawArc(testrect2, 0, 16 * 360);

		foreach(int index, fingers){
			data = thePoints[index];

			QLine line(data.x, data.y, avgX, avgY);
			painter.drawLine(line);
		}

		painter.end();

		// Update small portion of the screen
		bool b = this->updatesEnabled();
		int rad = 2;
		update(testrect.toRect().adjusted(-rad, -rad, +rad, +rad));
		update(testrect2.toRect().adjusted(-rad, -rad, +rad, +rad));
	}
}

bool DrawArea::getCircle(touchData data1, touchData data2, touchData data3, float &centerX, float &centerY, float &radius){
	/* Rough equation found here: http://regentsprep.org/regents/math/geometry/gcg6/RCir.htm */
	/* To be looked at further: "Least Square Circle Fitting"
		http://www.dtcenter.org/met/users/docs/write_ups/circle_fit.pdf */

	float rslope, tslope;// , centerX, centerY;

	if (data1.x == data3.x || data2.x == data3.x) return false;
	rslope = (data1.y - data3.y) / (float)(data1.x - data3.x);
	tslope = (data2.y - data3.y) / (float)(data2.x - data3.x);
	if (rslope != tslope && rslope != -tslope) {
		// X = ( r*t*(y2-y1) + r*(x3+x2) - t(x1+x3) ) / (2*(r-t))
		centerX = rslope*tslope*(data2.y - data1.y);
		centerX += rslope*(data3.x + data2.x);
		centerX -= tslope*(data3.x + data1.x);
		centerX /= 2 * (rslope - tslope);

		// y = (- 1/r) ( X - ((x1 + x3) / 2) ) + ((y1 + y3) / 2)
		centerY = ((data3.x + data1.x) / 2.0) - centerX;
		centerY /= rslope;
		centerY += (data3.y + data1.y) / 2.0;

		radius = sqrt((centerX - data1.x)*(centerX - data1.x) + (centerY - data1.y)*(centerY - data1.y));
		return true;
	} else return false;
}

void DrawArea::drawFinger(touchData data){
	//clearScreen();
	QRectF rect = QRectF(data.x - (brushSize / 2), data.y - (brushSize / 2), brushSize, brushSize);
	QRectF rect2 = QRectF(data.x - (brushSize / 3), data.y - (brushSize / 3), 2*brushSize / 3, 2*brushSize / 3);
	if (rect.isEmpty()) {
		qreal diameter = qreal(50) * 1;
		rect.setSize(QSizeF(diameter, diameter));
	}

	QPainter painter(&image);

	QPen pen(Qt::SolidLine);
	pen.setColor(idColors.at(data.id % idColors.count()));
	pen.setWidth(brushSize / 10);
	painter.setPen(pen);
	painter.drawArc(rect, 0, 16 * 360);
	painter.drawArc(rect2, 0, 16 * 360);

	// Draw Text
	QString str = tr(std::to_string(data.id).c_str());//tr("( " + data.id + " )");

	QFont font("Ariel");//"Helvetica");
	font.setPointSize(brushSize / 2);
	painter.setFont(font);
	QFontMetrics fMetrics = painter.fontMetrics();
	QSize sz = fMetrics.size(Qt::TextSingleLine, str);
	//QRectF txtRect(rect.center(), sz);
	QPoint p(data.x - sz.rwidth() / 2, data.y + rect.height() / 2);
	QRectF txtRect(p, sz);
	painter.drawText(txtRect, Qt::TextSingleLine, str);
	//painter.drawRect(txtRect);
	//QPoint p(data.x, data.y);
	//painter.drawText(p, str);

	// Testing Purposes
	/*QRectF testrect = QRectF(data.x-2, data.y-2, 4, 4);
	painter.setBrush(idColors.at((data.id + 1) % idColors.count()));
	painter.drawEllipse(testrect);*/

	painter.end();

	// Update small portion of the screen
	bool b = this->updatesEnabled();
	int rad = 2;
	update(rect.toRect().adjusted(-rad, -rad, +rad, +rad));
}

/*Draws a clear immage the size of the draw area
effectively clearing the screen*/
void DrawArea::clearScreen()
{
	qDebug() << "CLEARING THE SCREEN";
	image.fill(qRgb(255, 255, 255));
	update();
}

/*Supplementary function that draws the image into the screen*/
void DrawArea::paintEvent(QPaintEvent *event)
{
	QPainter painter(this);
	const QRect rect = event->rect();
	painter.drawImage(rect.topLeft(), image, rect);
}

/*Supplementary function that triggers an imageResize*/
void DrawArea::resizeEvent(QResizeEvent *event)
{
	if (width() > image.width() || height() > image.height())
	{
		int newWidth = qMax(width() + 128, image.width());
		int newHeight = qMax(height() + 128, image.height());
		resizeImage(&image, QSize(newWidth, newHeight));
		update();
	}
	QWidget::resizeEvent(event);
}

/*Supplementary function that resizes the image*/
void DrawArea::resizeImage(QImage *image, const QSize &newSize)
{
	if (image->size() == newSize)
		return;
	QImage newImage(newSize, QImage::Format_RGB32);
	newImage.fill(qRgb(255, 255, 255));
	QPainter painter(&newImage);
	painter.drawImage(QPoint(0, 0), *image);
	*image = newImage;
}

/*The function that does all the input/output,
this function gets triggered by a touch event,
saves the data of the touch event as a touch point 
and adds the touch point to a list, then draws the 
output depending on the mapping function*/
bool DrawArea::event(QEvent *event)
{
	static int init_time = 0;
	int time = clock();

	if (thePoints.isEmpty()){
		init_time = time;
	}

	switch (event->type())
	{
	case QEvent::MouseButtonPress:
		qDebug() << "Mouse Clicked" << endl;
		break;
	case QEvent::MouseButtonRelease:
		qDebug() << "Mouse Released" << endl;
		break;
	case QEvent::TouchBegin:
	case QEvent::TouchUpdate:
	case QEvent::TouchEnd:
		{
			QTouchEvent *touch = static_cast<QTouchEvent *>(event);
			QList<QTouchEvent::TouchPoint> touchPoints = static_cast<QTouchEvent *>(event)->touchPoints();
			foreach(const QTouchEvent::TouchPoint &touchPoint, touchPoints)
			{
				switch (touchPoint.state())
				{
				case Qt::TouchPointStationary:
					continue;
				case Qt::TouchPointReleased:
					touchData data;
					data.x = -1;
					data.y = -1;
					data.id = touchPoint.id();
					data.time = time - init_time;//time(NULL);

					updateData(data);
					clearScreen();
					drawScreen();
					break;
				case Qt::TouchPointPressed:
				case Qt::TouchPointMoved:
				default:
				{
					touchData data;
					data.x = touchPoint.pos().rx() * mapping;
					data.y = touchPoint.pos().ry() * mapping;
					data.id = touchPoint.id();
					data.time = time - init_time;//time(NULL);

					//EDIT: Updat info created
					updateData(data);

					// EDIT: Encapsulate the drawing of touch events into one function
					clearScreen();
					drawScreen();
					
					/*
					QPainter painter(&image);
					painter.setPen(Qt::NoPen);
					painter.setBrush(idColors.at(touchPoint.id() % idColors.count()));
					painter.drawEllipse(rect);
					painter.end();

					int rad = 2;
					update(rect.toRect().adjusted(-rad, -rad, +rad, +rad));*/
				}
				break;
				}
			}
			break;
		}
	default:
		return QWidget::event(event);
	}
	return true;
}