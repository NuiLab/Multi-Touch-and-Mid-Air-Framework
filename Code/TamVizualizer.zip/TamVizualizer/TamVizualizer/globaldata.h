#ifndef GLOBALDATA_H
#define GLOBALDATA_H

#include <cstdlib>

using namespace std;

/*The structure to hold the data of a touch input*/
struct touchdata
{
	long long x;
	long long y;
	int id;
	time_t timeStamp;
};
#endif