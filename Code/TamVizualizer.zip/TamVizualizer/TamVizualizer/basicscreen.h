/*#ifndef BASICSCREEN_H
#define BASICSCREEN_H

#include "basicdraw.h"
#include "basichand.h"
#include "debug.h"

class BasicScreen : public QWidget
{
	Q_OBJECT
public:
	QImage screen;
	BasicHand hand;
	BasicScreen(QWidget *parent = 0){
		setAttribute(Qt::WA_AcceptTouchEvents);
		setAttribute(Qt::WA_StaticContents);
	}
	BasicScreen(QWidget *parent = 0, QImage &image){
		setAttribute(Qt::WA_AcceptTouchEvents);
		setAttribute(Qt::WA_StaticContents);
		screen = image;
	}

	virtual void draw() = 0;
	void update(touchData data){
		hand.update(data);
	}
}

#endif*/