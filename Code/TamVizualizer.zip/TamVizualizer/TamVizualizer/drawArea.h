#ifndef DRAWAREA_H
#define DRAWAREA_H

#include <cstdlib>
#include <qcolor.h>
#include <qimage.h>
#include <qpoint.h>
#include <qwidget.h>

#include "basicscreen.h"
#include "debug.h"

using namespace std;

class DrawArea : public QWidget
{
	Q_OBJECT

public:
	DrawArea(QWidget *parent = 0);

	/*The structure to hold the data of a touch input*/
	struct touchData
		{
			long long x;
			long long y;
			int id;
			int time;
		};

	/*Changes the global brushSize attribute*/
	void doResizeBrush(int i);

	/*Changes the global mapping attribute*/
	void doMap(int map);

	/*Starts the save action by opening a save dialog native to the OS*/
	bool doSaveGesture(QString fileName, QString fileType);

	/*Starts the open actionn by opening an open dialog native to the OS*/
	bool doOpenGesture(QString fileName, QString fileType);

	/*Slots used for communication between DrawArea and MainWindow*/
	public slots:
	void playback();
	void clearScreen();

protected:
	/*The main function that gets triggered when a touch event happens*/
	bool event(QEvent *event);

	/*A supplementary function that does the 2D painting*/
	void paintEvent(QPaintEvent *event);

	/*A supplementary function for controlling window size*/
	void resizeEvent(QResizeEvent *event);

	/* A list of color objects*/
	QList<QColor> idColors;
	
	// Basic Screen Test
	//BasicScreen screen;
private:
	/*Global size of the brush*/
	int brushSize = 50;

	/*Global value for mapping function*/
	double mapping = 1;

	/*Global immage object to draw*/
	QImage image;

	/*Global list of all the touchPoints*/
	QList<touchData> thePoints;

	/*Global position of all 10 fingers currently*/
	//int fingers[10];
	QHash<int, int> fingers;

	/*A supplementary function for controlling window size*/
	void resizeImage(QImage *image, const QSize &newSize);

	/*Supplementary function to display the touch points in the debug monitor*/
	void printthedata();

	/*Update the touch data for the 10 fingers*/
	void updateData(touchData data);

	/*Draws the screen along with the finger and hand positions on screen*/
	void drawScreen();

	/*Draws the fingers on the screen given the touch data*/
	void drawFinger(touchData data);
	
	/*Calculates circle given 3 touch data points*/
	bool getCircle(touchData data1, touchData data2, touchData data3, float &centerX, float &centerY, float &radius);
};
#endif