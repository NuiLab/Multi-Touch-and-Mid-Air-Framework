/*#ifndef BASICDRAW_H
#define BASICDRAW_H

#include <cstdlib>
#include <qcolor.h>
#include <qimage.h>
#include <qpoint.h>
#include <qwidget.h>

#include "globaldata.h"
#include "basichand.h"
#include "debug.h"

using namespace std;

class BasicDraw : public QWidget
{
	Q_OBJECT
protected:
	const void drawEllipse(QPainter screen, QRectF rect, QColor color, bool fill);
	static void drawHorizLine(QPainter screen, long y, int width, QColor color);
	static void drawVertLine(QPainter screen, long x, int width, QColor color);
	static void drawHand(QPainter screen, BasicHand hand);
}

#endif*/