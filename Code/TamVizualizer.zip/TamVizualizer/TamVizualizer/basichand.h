/*#ifndef BASICHAND_H
#define BASICHAND_H

#include "globaldata.h"
#include "debug.h"

class BasicHand {
public:
	touchData data_list[];	// List of touch data for each unique id
	int f_table[];		// Table to store id of fingers from left to right

	void draw();
	void update(touchData data);
	int getFingerData(int id);
	void drawFinger(touchData data);
protected:
	static bool generatePalms(&QVector2D palm1, &QVector2D palm2);
}

#endif*/