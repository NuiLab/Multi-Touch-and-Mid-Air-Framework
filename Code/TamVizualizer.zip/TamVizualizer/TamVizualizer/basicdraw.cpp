/*#include "basicdraw.h"

using namespace std;

const void BasicDraw::drawEllipse(QPainter screen, QRectF rect, QColor color, bool fill) {
	if (fill){
		screen.setPen(Qt::NoPen);
		painter.setBrush(idColors.at(touchPoint.id() % idColors.count()));
		painter.drawEllipse(rect);
		painter.end();
	} else {

	}
}*/